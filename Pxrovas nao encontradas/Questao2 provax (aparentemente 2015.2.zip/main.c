/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int dia, mes, ano, bissexto;
    int diaseguinte, messeguinte, anoseguinte;

    
    printf("Digite a data(dia,mes,ano): ");
    scanf("%i%i%i", &dia, &mes, &ano);
    
    bissexto= ano%4;
    
    if(mes==2){
        anoseguinte= ano;
        if(bissexto!=0){            //se for bissexto //falta checar as outras condições do bissexto.
         if(dia==29){
          diaseguinte= 1;
          messeguinte= 3;}
          else{
            diaseguinte= dia+1;
            messeguinte= mes; }}
        else{                         //não sendo bissexto
            if(dia==28){
            diaseguinte= 1;
            messeguinte= 3;}
             else{
               diaseguinte= dia+1;
               messeguinte= mes;}
            }  
    }

         
          
     if(mes==12){
     if(dia=31){
         diaseguinte=1;
         messeguinte=1;
         anoseguinte= ano+1;}
         else{
             diaseguinte= dia+1;}
         }
        
    
    else                                  //fim das exceções
    
    anoseguinte= ano;
    
    
    if(mes==1|| mes==3|| mes==5|| mes== 7|| mes== 8|| mes==10){
        if(dia<31){
            diaseguinte= dia+1;
            messeguinte= mes;
        }
         else{
             diaseguinte= 1;
             messeguinte= mes+1;}
         }
            
    
    
    if(mes==4|| mes==6|| mes==9|| mes==11){
        if(dia<30){
            diaseguinte= dia+1;
            messeguinte= mes;
        }
         else{
             diaseguinte= 1;
             messeguinte= mes+1;}
         }
             
    
        
  printf("data seguinte: %i %i %i", diaseguinte, messeguinte, anoseguinte);    
    

    return 0;
}

