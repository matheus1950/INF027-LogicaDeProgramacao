/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int n, divisor, soma, k, qtd;

scanf("%i", &k);

n=1;
qtd=0;

while(k>=qtd){
soma=0;
divisor=1;

while(n>=divisor){
    
if(n%divisor==0){
soma+=divisor;}

divisor++;
}

if(soma>(2*n)){
printf("número: %i\n", n);
printf("soma: %i\n", soma);
printf("abundante\n\n");
qtd++;
}
n++;
}

    return 0;
}
